import os
import sys

_native_dir = os.path.join(os.path.dirname(__file__), '_native')
if _native_dir not in sys.path:
    sys.path.insert(0, _native_dir)
if hasattr(os, 'add_dll_directory'):
    os.add_dll_directory(_native_dir)

from tlsrs import Client, Response, Session

__all__ = ['Client', 'Response', 'Session']
